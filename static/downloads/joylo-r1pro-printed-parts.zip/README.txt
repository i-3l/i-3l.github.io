JoyLo+ R1 Pro: custom links and grip parts

This archive contains 9 individual STL meshes from the single-arm
leader CAD used by the hardware viewer. See parts.csv for filenames, quantities
and bounding-box dimensions. Assembly models are available separately in the BOM.

Units: millimetres. Import at 100% scale in a slicer that uses millimetres.
The source geometry has been converted from metres to millimetres; triangles
and CAD orientations are unchanged. Arrange and orient each part for your
printer, then choose suitable material, supports and print settings.
These files do not include a tested slicer profile or G-code.

The set covers one leader's custom link and grip geometry. Servo assemblies,
hinges, electronics, fasteners and the bimanual mounting bar are not included.
